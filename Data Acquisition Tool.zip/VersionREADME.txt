This zip file contains the installers for 2 versions of the Data Acquisition Tool:
1. Data Acquisition Tool R2014b.mlappinstall
2. Data Acquisition preR2014b.mlappinstall

The version labeled, "Data Acquisition Tool R2014b," only works on R2014b and newer.
The version labeled, "Data Acquisition preR2014b," works on R2013b to R2014b.